	component nios_system is
		port (
			clk_clk           : in  std_logic                    := 'X';             -- clk
			leds_export       : out std_logic_vector(7 downto 0);                    -- export
			pushbutton_export : in  std_logic_vector(3 downto 0) := (others => 'X'); -- export
			reset_reset_n     : in  std_logic                    := 'X'              -- reset_n
		);
	end component nios_system;

	u0 : component nios_system
		port map (
			clk_clk           => CONNECTED_TO_clk_clk,           --        clk.clk
			leds_export       => CONNECTED_TO_leds_export,       --       leds.export
			pushbutton_export => CONNECTED_TO_pushbutton_export, -- pushbutton.export
			reset_reset_n     => CONNECTED_TO_reset_reset_n      --      reset.reset_n
		);

